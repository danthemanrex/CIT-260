import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.println("This program calculates the number of days in a given month of a given year.");
        System.out.print("Enter a year: ");
        Scanner input = new Scanner(System.in);
        int year = input.nextInt();
        System.out.print("Enter a month (1 = Jan, 2 = Feb, etc.): ");
        int month = input.nextInt();
        if (month < 1 || month > 12) {
            System.out.println("Invalid input. Terminating program.");
            input.close();
            return;
        }
        int days;
        boolean isLeapYear = (year % 4 == 0 && year % 100 != 0) || year % 400 == 0;
        days = switch (month) {
            case 2 -> isLeapYear ? 29 : 28;
            case 4, 6, 9, 11 -> 30;
            default -> 31;
        };
        System.out.println("There are " + days + " days in that month.");
        System.out.println("Goodbye!");
        input.close();
    }
}
