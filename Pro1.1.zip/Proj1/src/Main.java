import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // Tell the user what the program does
        System.out.println("This program calculates the number of days in a given month of a given year.");

        // Prompt the user to enter a year
        System.out.print("Enter a year: ");

        // Read the user's input and save it
        Scanner scanner = new Scanner(System.in);
        int year = scanner.nextInt();

        // Prompt the user to enter a value for the month
        System.out.print("Enter a value for the month (1 for January, 2 for February, etc.): ");

        // Read the user's input and save it
        int month = scanner.nextInt();

        // If the value is invalid, tell the user and terminate the program
        if (month < 1 || month > 12) {
            System.out.println("Invalid input. The value must be between 1 and 12 (inclusive).");
            return;
        }

        // Calculate the number of days in the month
        int daysInMonth;
        switch (month) {
            case 1:  // January
            case 3:  // March
            case 5:  // May
            case 7:  // July
            case 8:  // August
            case 10: // October
            case 12: // December
                daysInMonth = 31;
                break;
            case 2:  // February
                if (year % 4 == 0 && year % 100 != 0 || year % 400 == 0) {
                    daysInMonth = 29;  // leap year
                } else {
                    daysInMonth = 28;
                }
                break;
            case 4:  // April
            case 6:  // June
            case 9:  // September
            case 11: // November
                daysInMonth = 30;
                break;
            default:
                // This should never happen, but just in case...
                daysInMonth = 0;
                break;
        }

        // Display the number of days in the month
        System.out.println("There are " + daysInMonth + " days in the month of " + month + " in the year " + year + ".");

        // Output a goodbye message
        System.out.println("Goodbye!");
    }
}
