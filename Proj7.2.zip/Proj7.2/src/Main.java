class Timecard {
    public static void main(String[] args) {
        // Create the array of employee names
        String[] names = {"Tara Teamlead", "Harry Hacker", "Carl Coder", "Paula Programmer", "Darrin Debugger"};

        // Create the array of timecard data
        double[][] hours = {
                {0.0, 8.0, 8.0, 8.5, 8.0, 9.0, 0.0},
                {0.0, 9.0, 9.0, 8.5, 8.0, 7.5, 0.0},
                {0.0, 8.5, 8.0, 8.6, 8.6, 9.5, 2.0},
                {0.0, 4.75, 6.0, 6.25, 6.5, 0.0, 0.0},
                {0.0, 0.0, 0.0, 0.0, 5.25, 5.25, 6.0}
        };

        // Compute the total hours for each employee
        double[] totals = new double[names.length];
        for (int i = 0; i < names.length; i++) {
            double total = 0.0;
            for (int j = 0; j < 7; j++) {
                total += hours[i][j];
            }
            totals[i] = total;
        }

        // Display the names and hours worked for that week
        System.out.println("This Program computes the number of hours worked for a set of hourly employees.\n");
        System.out.println("Employee Name        Total Hours");
        for (int i = 0; i < names.length; i++) {
            System.out.printf("%-20s%6.2f\n", names[i], totals[i]);
        }
        System.out.println("\nGoodbye");

        // Sort the array of names and totals in descending order of total hours
        for (int i = 0; i < names.length - 1; i++) {
            int maxIndex = i;
            for (int j = i + 1; j < names.length; j++) {
                if (totals[j] > totals[maxIndex]) {
                    maxIndex = j;
                }
            }
            if (maxIndex != i) {
                double tempTotal = totals[i];
                totals[i] = totals[maxIndex];
                totals[maxIndex] = tempTotal;
                String tempName = names[i];
                names[i] = names[maxIndex];
                names[maxIndex] = tempName;
            }
        }

        // Display the sorted names and hours worked for that week
        System.out.println("\nThis Program computes the number of hours worked for a set of hourly employees.\n");
        System.out.println("Employee Name        Total Hours");
        for (int i = 0; i < names.length; i++) {
            System.out.printf("%-20s%6.2f\n", names[i], totals[i]);
        }
        System.out.println("\nGoodbye");
    }
}
