import java.util.Scanner;

public class TriangleDriver {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.println("This program gets input for a triangle from the user.");
        System.out.println("It then creates a Triangle object and displays its description.\n");

        System.out.print("Enter the color of the triangle (e.g. \"red\"): ");
        String color = input.nextLine();

        System.out.print("Is the triangle filled (y or n): ");
        boolean filled = input.nextLine().equalsIgnoreCase("y");

        System.out.print("Enter the non-zero, positive lengths of the three sides of the triangle: ");
        double side1 = input.nextDouble();
        double side2 = input.nextDouble();
        double side3 = input.nextDouble();

        Triangle t1 = new Triangle(side1, side2, side3, color, filled);

        System.out.println("\nTriangle Output:");
        System.out.printf("side1 = %.1f, side2 = %.1f, side3 = %.1f\n", t1.getSide1(), t1.getSide2(), t1.getSide3());
        System.out.print( "\nCreated on " + t1.getDateCreated());
        System.out.printf("\nArea = %s", t1.getArea());
    }
}