import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.println("Given an investment amount and an annual interest rate, this program \n" +
                "will calculate the future value of the investment for a period of \n" +
                "ten years.");
        Scanner sc = new Scanner(System.in);
        double investmentAmount = 0;
        double interestRate = 0;

        // Prompt and get investment amount
        do {
        System.out.print("Enter the a positive, non-zero value for the investment: ");
        investmentAmount = sc.nextDouble();
        if (investmentAmount <= 0) {
        System.out.println("Error: Investment amount must be positive and non-zero.");
        }
        } while (investmentAmount <= 0);

        // Prompt and get interest rate
        do {
        System.out.print("Enter an annual interest rate, between 0 and 100: ");
        interestRate = sc.nextDouble();
        if (interestRate <= 0 || interestRate > 100) {
        System.out.println("Error: Interest rate must be positive and less than or equal to 100.");
        }
        } while (interestRate <= 0 || interestRate > 100);

        System.out.println();
        System.out.println("Years\tFuture Value");

        // Calculate and display future values
        double monthlyInterestRate = interestRate / 12 / 100;
        int years = 10;
        for (int i = 1; i <= years; i++) {
        double futureValue = futureValue(investmentAmount, monthlyInterestRate, i);
        System.out.println(i + "\t$" + String.format("%.2f", futureValue));
        }

        System.out.println("\nGoodbye...");
        sc.close();
        }

public static double futureValue(double investmentAmount, double monthlyInterestRate, int years) {
        return investmentAmount * Math.pow(1 + monthlyInterestRate, years * 12);
        }
}