import java.text.DecimalFormat;
import java.util.Scanner;

class Main {
    public static void main(String[] args) {
        System.out.println("This program calculates payroll information.");

        Scanner input = new Scanner(System.in);
        System.out.print("Enter your first name: ");
        String firstName = input.nextLine();
        System.out.print("Enter your last name: ");
        String lastName = input.nextLine();

        System.out.print("Enter the number of hours worked this week: ");
        double hoursWorked = input.nextDouble();
        System.out.print("Enter your hourly wage: ");
        double hourlyWage = input.nextDouble();

        double grossPay = hoursWorked * hourlyWage;
        double stateTax = grossPay * 0.09;
        double federalTax = grossPay * 0.2;
        double netPay = grossPay - stateTax - federalTax;

        DecimalFormat df = new DecimalFormat("#.00");
        System.out.println("Pay statement for " + firstName + " " + lastName);
        System.out.println("Gross pay: $" + df.format(grossPay));
        System.out.println("State withholding tax: $" + df.format(stateTax));
        System.out.println("Federal withholding tax: $" + df.format(federalTax));
        System.out.println("Net pay: $" + df.format(netPay));

        System.out.println("Goodbye!");
    }
}
