public class Salaried extends Employee {
    private double annualSalary;

    // no-arg constructor
    public Salaried() {
        super();
        this.annualSalary = 0.0;
    }

    // parameterized constructor
    public Salaried(String name, int serialNumber, double annualSalary) {
        super(name, serialNumber);
        this.annualSalary = annualSalary;
    }

    // getter
    public double getSalary() {
        return this.annualSalary;
    }

    // methods
    @Override
    public double getGrossPay() {
        return this.annualSalary / 52.0;
    }

    @Override
    public double getFedWithholding() {
        return 0.15 * getGrossPay();
    }

    @Override
    public double getStateWithholding() {
        return 0.07 * getGrossPay();
    }
}
