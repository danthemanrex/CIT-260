public class Hourly extends Employee {
    private double hourlyWage;
    private double hoursWorked;

    // no-arg constructor
    public Hourly() {
        super();
        this.hourlyWage = 0.0;
        this.hoursWorked = 0.0;
    }

    // parameterized constructor
    public Hourly(String name, int serialNumber, double hourlyWage, double hoursWorked) {
        super(name, serialNumber);
        this.hourlyWage = hourlyWage;
        this.hoursWorked = hoursWorked;
    }

    // getters
    public double getHourlyWage() {
        return this.hourlyWage;
    }

    public double getHoursWorked() {
        return this.hoursWorked;
    }

    // methods
    @Override
    public double getGrossPay() {
        return this.hoursWorked * this.hourlyWage;
    }

    @Override
    public double getFedWithholding() {
        return 0.15 * getGrossPay();
    }

    @Override
    public double getStateWithholding() {
        return 0.07 * getGrossPay();
    }
}
