import java.util.ArrayList;

public class PayrollReport {
    public static void main(String[] args) {
        System.out.println("This program generates a payroll report for several employees.");

        // create an ArrayList to hold the employees
        ArrayList<Employee> employees = new ArrayList<>();

        // create instances for each employee and add them to the ArrayList
        employees.add(new Hourly("Harry Hacker", 123, 15.00, 30));
        employees.add(new Hourly("Isabel Intern", 233, 12.50, 20));
        employees.add(new Salaried("Cathy Coder", 611, 80000.00));

        System.out.println("\nPayroll Report");

        // loop through the employees in the ArrayList and print their payroll information
        for (Employee e : employees) {
            System.out.println("Employee: " + e.getName() + " Serial: " + e.getSerialNumber());

            double grossPay = e.getGrossPay();
            double federalTax = e.getFedWithholding();
            double stateTax = e.getStateWithholding();
            double netPay = grossPay - e.getFedWithholding() - e.getStateWithholding();

            System.out.printf("Gross Pay: $%.2f\n", grossPay);
            System.out.printf("Federal Withholding: $%.2f\n", federalTax);
            System.out.printf("State Withholding: $%.2f\n", stateTax);
            System.out.printf("Net Pay: $%.2f\n\n", netPay);
        }

        System.out.println("Thank you for using the payroll program!");
    }
}
