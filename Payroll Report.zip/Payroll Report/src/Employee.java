public class Employee {
    private String name;
    private int serialNumber;

    // no-arg constructor
    public Employee() {
        this.name = "none";
        this.serialNumber = 0;
    }

    // parameterized constructor
    public Employee(String name, int serialNumber) {
        this.name = name;
        this.serialNumber = serialNumber;
    }

    // getters
    public String getName() {
        return this.name;
    }

    public int getSerialNumber() {
        return this.serialNumber;
    }

    // methods
    public double getGrossPay() {
        return 0.0;
    }

    public double getFedWithholding() {
        return 0.0;
    }

    public double getStateWithholding() {
        return 0.0;
    }


}
