class BankAccountProgram {
    public static void main(String[] args) {
        System.out.println("This program tests the BankAccount class by ...");

        BankAccount account = new BankAccount(123, 5.0);

        account.makeDeposit(10.50);
        account.makeDeposit(3.25);
        account.makeWithdrawal(1.50);

        System.out.printf("The balance in account number %d is $%.2f\n", account.getAccountNumber(), account.getBalance());

        System.out.println("Goodbye...");
    }

    public static class BankAccount {
        private int accountNumber;
        private double balance;

        public BankAccount() {
            accountNumber = 0;
            balance = 0.0;
        }

        public BankAccount(int accountNumber, double balance) {
            this.accountNumber = accountNumber;
            this.balance = balance;
        }

        public int getAccountNumber() {
            return accountNumber;
        }

        public double getBalance() {
            return balance;
        }

        public void makeDeposit(double amount) {
            balance += amount;
        }

        public void makeWithdrawal(double amount) {
            balance -= amount;
        }
    }
}
