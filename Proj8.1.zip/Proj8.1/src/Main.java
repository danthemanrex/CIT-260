import java.text.DecimalFormat;

class RectangleMain {
    public static void main(String[] args) {
        DecimalFormat decimalFormat = new DecimalFormat("0.00");

        System.out.println("This program creates two rectangle objects and displays their width, height, area and perimeter.\n");

        Rectangle rectangle1 = new Rectangle(40, 4);
        System.out.println("Rectangle 1:");
        System.out.println("height = " + decimalFormat.format(rectangle1.getHeight()));
        System.out.println("width = " + decimalFormat.format(rectangle1.getWidth()));
        System.out.println("area = " + decimalFormat.format(rectangle1.getArea()));
        System.out.println("perimeter = " + decimalFormat.format(rectangle1.getPerimeter()) + "\n");

        Rectangle rectangle2 = new Rectangle(5, 3.5);
        System.out.println("Rectangle 2:");
        System.out.println("height = " + decimalFormat.format(rectangle2.getHeight()));
        System.out.println("width = " + decimalFormat.format(rectangle2.getWidth()));
        System.out.println("area = " + decimalFormat.format(rectangle2.getArea()));
        System.out.println("perimeter = " + decimalFormat.format(rectangle2.getPerimeter()));

        System.out.println("\ngoodbye ...");
    }
}

class Rectangle {
    private double width;
    private double height;

    public Rectangle() {
        this.width = 1.0;
        this.height = 1.0;
    }

    public Rectangle(double width, double height) {
        this.width = width;
        this.height = height;
    }

    public double getWidth() {
        return width;
    }

    public void setWidth(double width) {
        this.width = width;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    public double getArea() {
        return width * height;
    }

    public double getPerimeter() {
        return 2 * (width + height);
    }
}
