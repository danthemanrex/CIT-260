import java.util.ArrayList;

class Shape {
    private int identifier;
    private double area;

    public Shape(int identifier, double area) {
        this.identifier = identifier;
        this.area = area;
    }

    public int getIdentifier() {
        return identifier;
    }

    public double getArea() {
        return area;
    }
}

class Circle extends Shape {
    private double radius;

    public Circle(int identifier, double radius) {
        super(identifier, Math.PI * radius * radius);
        this.radius = radius;
    }

    public double getRadius() {
        return radius;
    }
}

class Square extends Shape {
    private double side;

    public Square(int identifier, double side) {
        super(identifier, side * side);
        this.side = side;
    }

    public double getSide() {
        return side;
    }
}

class RightTriangle extends Shape {
    private double height;
    private double base;

    public RightTriangle(int identifier, double height, double base) {
        super(identifier, 0.5 * height * base);
        this.height = height;
        this.base = base;
    }

    public double getHeight() {
        return height;
    }

    public double getBase() {
        return base;
    }
}

public class Main {
    public static void main(String[] args) {
        ArrayList<Shape> shapes = new ArrayList<>();
        shapes.add(new Circle(156, 10.0));
        shapes.add(new Square(237, 2.0));
        shapes.add(new RightTriangle(212, 3.0, 4.0));

        System.out.println("Identifier Area");
        for (Shape shape : shapes) {
            System.out.printf("%d %14.2f sq. inches\n", shape.getIdentifier(), shape.getArea());
        }
    }
}
