public class Main {
    public static void main(String[] args) {
        System.out.println("This program converts temperatures between Celsius and Fahrenheit.");
        System.out.println("Celsius\tFahrenheit\t|\tFahrenheit\tCelsius");
        System.out.println("--------------------------------------------------------");

        for (double celsius = 40.0; celsius >= 31.0; celsius--) {
            double fahrenheit = celsiusToFahrenheit(celsius);
            System.out.printf("%.1f\t\t%.1f\t\t|\t%.1f\t\t%.2f\n", celsius, fahrenheit, fahrenheit, fahrenheitToCelsius(fahrenheit));
        }

        System.out.println("Goodbye...");
    }

    public static double celsiusToFahrenheit(double tempCelsius) {
        return tempCelsius * 9.0 / 5.0 + 32.0;
    }

    public static double fahrenheitToCelsius(double tempFahrenheit) {
        return (tempFahrenheit - 32.0) * 5.0 / 9.0;
    }
}
