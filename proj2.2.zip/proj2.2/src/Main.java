import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // Tell the user what the program does
        System.out.println("This program calculates the bill for your meal with tip, tax and total amount.");

        // Create a Scanner object for user input
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter the cost of their meal
        System.out.print("Enter the cost of your meal: $");

        // Get the user's input and save it in a variable
        double mealCost = scanner.nextDouble();

        // Prompt the user to enter a tip percentage
        System.out.print("Enter the tip percentage: ");

        // Get the user's input and save it in a variable
        double tipPercent = scanner.nextDouble();

        // Calculate the tip
        double tip = mealCost * tipPercent / 100;

        // Calculate the tax
        double tax = mealCost * 0.032;

        // Calculate the total bill
        double totalBill = mealCost + tip + tax;

        // Output the tip, tax, and total bill
        System.out.printf("Tip: $%.2f\n", tip);
        System.out.printf("Tax: $%.2f\n", tax);
        System.out.printf("Total Bill: $%.2f\n", totalBill);

        // Output a goodbye message
        System.out.println("Thank you for using this program!");
    }
}
