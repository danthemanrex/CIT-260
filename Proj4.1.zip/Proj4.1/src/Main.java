import java.util.Scanner;

class HexToBinary {
    public static void main(String[] args) {
        System.out.println("This program converts a single hexadecimal digit to a four digit binary number.");

        Scanner input = new Scanner(System.in);
        System.out.print("Enter a single hexadecimal digit: ");
        String hex = input.nextLine();

        if (!isValidHex(hex)) {
            System.out.println("Invalid input, please enter a single hexadecimal digit.");
            return;
        }

        String binary = hexToBinary(hex);
        System.out.println("The binary representation of " + hex + " is " + binary);

        System.out.println("Goodbye!");
    }

    public static boolean isValidHex(String hex) {
        if (hex.length() != 1) {
            return false;
        }
        char c = hex.charAt(0);
        return (c >= '0' && c <= '9') || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F');
    }

    public static String hexToBinary(String hex) {
        int decimal = Integer.parseInt(hex, 16);
        StringBuilder binary = new StringBuilder(Integer.toBinaryString(decimal));
        while (binary.length() < 4) {
            binary.insert(0, "0");
        }
        return binary.toString();
    }
}
