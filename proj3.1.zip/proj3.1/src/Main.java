import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.println("This program calculates the day of the week for today and a future day.");
        System.out.print("Enter today's day of the week (0 for Sunday, 1 for Monday, etc.): ");
        Scanner input = new Scanner(System.in);
        int today = input.nextInt();
        if (today < 0 || today > 6) {
            System.out.println("Invalid input. Terminating program.");
            input.close();
            return;
        }
        String[] days = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};
        System.out.print("Enter the number of days in the future: ");
        int daysInFuture = input.nextInt();
        if (daysInFuture < 0) {
            System.out.println("Invalid input. Terminating program.");
            input.close();
            return;
        }
        int future = (today + daysInFuture) % 7;
        System.out.println("Today is " + days[today] + " and the future day is " + days[future] + ".");
        System.out.println("Goodbye!");
        input.close();
    }
}
