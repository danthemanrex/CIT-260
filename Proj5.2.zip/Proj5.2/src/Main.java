public class Main {
        public static void main(String[] args) {
            System.out.println("This program displays all of the numbers from 100 to 1000");
            System.out.println("that are divisible by both 5 and 6.");
            System.out.println();
            int count = 0;
            for (int i = 100; i <= 1000; i++) {
                if (i % 5 == 0 && i % 6 == 0) {
                    System.out.print(i + " ");
                    count++;
                    if (count % 10 == 0) {
                        System.out.println();
                    }
                }
            }
            System.out.println("\n\nGoodbye");
        }
    }
