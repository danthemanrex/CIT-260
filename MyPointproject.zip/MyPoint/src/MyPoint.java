public class MyPoint {
    private int x;
    private int y;

    public MyPoint() {
        this.x = 0;
        this.y = 0;
    }

    public MyPoint(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public double distance(int xCoord, int yCoord) {
        return Math.sqrt(Math.pow(x - xCoord, 2) + Math.pow(y - yCoord, 2));
    }

    public double distance(MyPoint p) {
        return distance(p.getX(), p.getY());
    }

    public static double distance(MyPoint mp1, MyPoint mp2) {
        return mp1.distance(mp2);
    }
}