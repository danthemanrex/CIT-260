import java.util.Scanner;

public class MyPointDemo {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.println("This program creates a point at (0,0) and a point at the coordinates");
        System.out.println("entered by you. It then computes and displays the distance from (0,0)");
        System.out.println("to the point defined by you, using three different methods.");

        MyPoint p1 = new MyPoint();

        System.out.print("Enter the x coordinate of a point: ");
        int x = input.nextInt();
        System.out.print("Enter the y coordinate of a point: ");
        int y = input.nextInt();

        double distance1 = p1.distance(x,y);
        System.out.printf("Using method 1, the distance from (0,0) to (%d,%d) is %.2f\n", x,y,distance1);

        MyPoint p2 = new MyPoint(x,y);

        double distance2 = p1.distance(p2);
        System.out.printf("Using method 2, the distance from (0,0) to (%d,%d) is %.2f\n", x,y,distance2);

        double distance3 = MyPoint.distance(p1,p2);
        System.out.printf("Using method 3, the distance from (0,0) to (%d,%d) is %.2f\n", x,y,distance3);

        System.out.println("Goodbye...");
    }
}