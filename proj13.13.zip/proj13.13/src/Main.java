import java.util.ArrayList;
import java.awt.Point;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;

class Shape {
    private int identifier;
    private double area;
    private Point position;

    public Shape(int identifier, double area, Point position) {
        this.identifier = identifier;
        this.area = area;
        this.position = position;
    }

    public int getIdentifier() {
        return identifier;
    }

    public double getArea() {
        return area;
    }

    public Point getPosition() {
        return position;
    }
}

class Circle extends Shape {
    private double radius;

    public Circle(int identifier, double radius, Point position) {
        super(identifier, Math.PI * radius * radius, position);
        this.radius = radius;
    }

    public double getRadius() {
        return radius;
    }
}

class Square extends Shape {
    private double side;

    public Square(int identifier, double side, Point position) {
        super(identifier, side * side, position);
        this.side = side;
    }

    public double getSide() {
        return side;
    }
}

class RightTriangle extends Shape {
    private double height;
    private double base;

    public RightTriangle(int identifier, double height, double base, Point position) {
        super(identifier, 0.5 * height * base, position);
        this.height = height;
        this.base = base;
    }

    public double getHeight() {
        return height;
    }

    public double getBase() {
        return base;
    }
}

public class Main {
    public static void main(String[] args) {
        System.out.println("This program creates a list of shapes and stores their data in a text file.");
        System.out.println("Shape       ID Position  Area");

        ArrayList<Shape> shapes = new ArrayList<>();
        shapes.add(new Circle(156, 10.0, new Point(1,1)));
        shapes.add(new Square(237, 2.0, new Point(1,3)));
        shapes.add(new RightTriangle(212, 3.0, 4.0,new Point(3,3)));

        try (FileWriter writer = new FileWriter("shapes.txt")) {
            for (Shape shape : shapes) {
                writer.write(shape.getClass().getSimpleName() + " " + shape.getIdentifier() + " " + shape.getPosition().x + " " + shape.getPosition().y + " " + shape.getArea() + "\n");
            }
            writer.flush();
            writer.close();

        } catch (IOException e) {
            System.out.println("An error occurred while writing to the file.");
            e.printStackTrace();
        }

        try (BufferedReader reader = new BufferedReader(new FileReader("shapes.txt"))) {
            String line = reader.readLine();
            while (line != null) {
                String[] data = line.split(" ");
                String type = data[0];
                int id = Integer.parseInt(data[1]);
                int x = Integer.parseInt(data[2]);
                int y = Integer.parseInt(data[3]);
                double area = Double.parseDouble(data[4]);
                System.out.printf("%-10s %3d (%d,%d) %8.2f sq. inches\n", type,id,x,y,area);
                line = reader.readLine();
            }
            reader.close();
            System.out.println("Data read from file.");
        } catch (IOException e) {
            System.out.println("An error occurred while reading from the file.");
            e.printStackTrace();
        }
    }
}