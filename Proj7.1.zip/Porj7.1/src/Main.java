import java.util.Scanner;

class MeanAndDeviation {

    /**
     * Computes and returns the mean value for an array of doubles.
     */
    public static double mean(double[] x) {
        double sum = 0;
        for (double v : x) {
            sum += v;
        }
        return sum / x.length;
    }

    /**
     * Computes and returns the standard deviation for a sample population.
     */
    public static double deviation(double[] x) {
        double mean = mean(x);
        double sum = 0;
        for (double v : x) {
            sum += Math.pow(v - mean, 2);
        }
        return Math.sqrt(sum / (x.length - 1));
    }

    public static void main(String[] args) {
        System.out.println("This program computes the mean and the standard deviation for a set of numbers.");
        Scanner scanner = new Scanner(System.in);
        double[] numbers = new double[5];
        for (int i = 0; i < 5; i++) {
            System.out.print("Enter a number: ");
            numbers[i] = scanner.nextDouble();
        }
        scanner.close();
        double mean = mean(numbers);
        double deviation = deviation(numbers);
        System.out.printf("The mean of this set of numbers is %.2f\n", mean);
        System.out.printf("The standard deviation is %.2f\n", deviation);
        System.out.println("Goodbye...");
    }
}
