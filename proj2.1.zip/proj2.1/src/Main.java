import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // Tell the user what the program does
        System.out.println("This program converts a temperature in degrees Celsius to degrees Fahrenheit.");

        // Create a Scanner object for user input
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to enter a temperature in degrees Celsius
        System.out.print("Enter a temperature in degrees Celsius: ");

        // Get the user's input and save it in a variable
        double celsius = scanner.nextDouble();

        // Convert the Celsius temperature to Fahrenheit
        double fahrenheit = (9.0/5.0) * celsius + 32;

        // Output the temperatures with 2 digits after the decimal point
        System.out.printf("%.2f degrees Celsius is equivalent to %.2f degrees Fahrenheit.\n", celsius, fahrenheit);

        // Output a goodbye message
        System.out.println("Thank you for using this program!");
    }
}
