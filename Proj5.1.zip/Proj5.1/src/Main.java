class Main {
    public static void main(String[] args) {
        System.out.println("This program calculates the equivalent weight in pounds for various weights in kilograms.");
        System.out.println("Kilograms\tPounds");
        for (int i = 1; i <= 10; i++) {
            double pounds = i * 2.2;
            System.out.println(i + "\t\t\t" + (double)Math.round(pounds * 10) / 10);
        }
        System.out.println("Goodbye!");
    }
}